import ProcessImage from './components/ProcessImage';

export default ProcessImage;
